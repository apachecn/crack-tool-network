原版下载地址：
https://portswigger.net/burp/releases

如Professional / Community 2022.9.1：
https://portswigger.net/burp/releases/download?product=pro&version=2022.9&type=Jar

使用说明（Java 11）：
java -noverify -javaagent:burp-loader-x-Ai-new.jar -jar burpsuite_pro_v2022.9.jar

补丁来源：
破解BurpSuite Pro 2022.9 (有变化)
https://www.52pojie.cn/thread-1687434-1-1.html